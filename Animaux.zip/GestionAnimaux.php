<?php

interface GestionAnimaux
{
    function achat($nouvelAnimal);
    function vente();
    function manger($typeNourriture);
}
